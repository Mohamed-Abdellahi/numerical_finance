"""
SobolGenerator
===============
Sobol low-discrepancy sequence for Quasi-Monte Carlo simulation.

Sobol sequences are a special case of Niederreiter sequences in base 2.
They have extremely low discrepancy and are widely used in financial QMC.

Requires scipy (pip install scipy).

Properties:
  - Much lower discrepancy than pseudo-random or Halton for high dimensions
  - Scrambling (optional) adds randomness while preserving low discrepancy
  - For best properties, use n = power of 2

Usage note on dimension
-----------------------
For a simulation with n assets and N time steps, each path requires
n*N independent uniform draws. The correct QMC approach is to set
dimension = n * N so that each path maps to a single point in [0,1]^(n*N).
generate() cycles through all d components before drawing the next point.
"""

from typing import Optional, List
from .uniform_generator import UniformGenerator


class SobolGenerator(UniformGenerator):
    """
    Sobol sequence generator using scipy.stats.qmc.Sobol.

    generate() cycles through all d components of each Sobol point before
    drawing the next one, so a simulation that calls generate() exactly d
    times per path correctly maps each path to one d-dimensional point.

    Parameters
    ----------
    dimension : int
        Dimension d of the Sobol sequence.
        For a simulation with n assets and N steps set d = n * N.
    scramble : bool
        Whether to scramble the sequence. Recommended for rQMC.
    seed : int or None
        Random seed for scrambling reproducibility.
    """

    def __init__(
        self,
        dimension: int = 1,
        scramble: bool = True,
        seed: Optional[int] = 42,
    ):
        super().__init__()
        try:
            from scipy.stats.qmc import Sobol
        except ImportError:
            raise ImportError(
                "scipy is required for SobolGenerator. "
                "Install with: pip install scipy"
            )
        self._dimension = dimension
        self._engine = Sobol(d=dimension, scramble=scramble, seed=seed)
        self._buffer: List[float] = []
        self._buffer_index = 0
        # batch size in number of d-dimensional points (not scalars)
        self._batch_size = 1024

    def generate(self) -> float:
        """
        Return the next scalar from the Sobol sequence.

        Internally generates points in [0,1]^d and returns their components
        one by one (row-major). After d calls the next d-dimensional point
        is drawn, so every group of d consecutive calls corresponds to one
        low-discrepancy point in the full d-dimensional space.
        """
        if self._buffer_index >= len(self._buffer):
            # shape (batch_size, d) -> flatten to (batch_size * d,)
            samples = self._engine.random(self._batch_size)
            self._buffer = samples.flatten().tolist()
            self._buffer_index = 0
        value = self._buffer[self._buffer_index]
        self._buffer_index += 1
        return float(value)

    def generate_vector(self, n: int) -> List[List[float]]:
        """
        Generate n samples of the full d-dimensional Sobol vector.

        Parameters
        ----------
        n : int
            Number of samples to generate.

        Returns
        -------
        list of list of float, shape (n, dimension)
        """
        return self._engine.random(n).tolist()

    @property
    def dimension(self) -> int:
        return self._dimension
