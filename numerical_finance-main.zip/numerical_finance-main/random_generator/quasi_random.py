"""
Quasi-Random Number Generators
================================
Low-discrepancy sequences for Quasi-Monte Carlo (QMC) simulation.

Implementations are in halton.py and sobol.py.
This module re-exports them for a grouped import.

Reference: Slides 3 (Kaiza Amouh), pages 42-50
"""

from .halton import HaltonGenerator
from .sobol import SobolGenerator

__all__ = ["HaltonGenerator", "SobolGenerator"]
