"""
CombinedMapping
================
Mapping qui combine simultanément les variables antithétiques ET la
variable de contrôle. Nécessaire pour la Question 1(b) cumulative.

Pour chaque appel :
  1. Simuler le chemin Z  → f(Z),  g(Z)
  2. Simuler le chemin -Z → f(-Z), g(-Z)
  3. Retourner : 0.5*(f(Z)+f(-Z))  - β * (0.5*(g(Z)+g(-Z)) - E[g])

Cette classe s'utilise aussi bien avec un générateur pseudo-aléatoire
(EcuyerCombined) qu'avec un générateur quasi-aléatoire (SobolGenerator),
ce qui permet d'obtenir la combinaison finale QMC + CV + Antithétique.

Usage
-----
mapping = CombinedMapping(
    process, main_payoff, cv_payoff, E_cv,
    T_pilot=T, nb_steps_pilot=nb_steps
)
result = engine.price(mapping, nb_paths=N, T=T, nb_steps=nb_steps, rate=r)
"""

from typing import List

from payoff.payoff import Payoff
from sde.random_process import RandomProcess
from sde.bs_milstein_1d import BSMilstein1D
from sde.bs_milstein_nd import BSMilsteinND
from sde.cholesky import recover_correlation
from random_generator.normal import NormalBoxMuller
from .mc_mapping import MCMapping


class _AntitheticNormal(NormalBoxMuller):
    """
    Adaptateur interne : retourne -Z pour chaque Z produit par le
    générateur associé. Partage le même flux aléatoire (pas de graine
    séparée) — les deux chemins Z et -Z sont corrélés par construction.
    """
    def __init__(self, paired: NormalBoxMuller):
        self._paired = paired   # NE PAS appeler super().__init__()

    def generate(self) -> float:
        return -self._paired.generate()


class CombinedMapping(MCMapping):
    """
    Variables antithétiques + variable de contrôle, en un seul mapping.

    Parameters
    ----------
    process : BSMilstein1D ou BSMilsteinND
        Processus principal (chemin Z).
    main_payoff : Payoff
        Le payoff à pricer (f).
    cv_payoff : Payoff
        Payoff de la variable de contrôle avec prix analytique connu (g).
        Doit implémenter analytical_price() (ex : GeometricBasketPayoff).
    E_cv : float
        Espérance analytique de g, NON actualisée :
        E_cv = cv_payoff.analytical_price() * exp(r * T)
    T_pilot : float
        Maturité utilisée pour la simulation pilote (= T du pricing).
    nb_steps_pilot : int
        Nombre de pas pour la simulation pilote.
    pilot_paths : int
        Nombre de chemins pour estimer β. Défaut : 2 000.
    """

    def __init__(
        self,
        process: RandomProcess,
        main_payoff: Payoff,
        cv_payoff: Payoff,
        E_cv: float,
        T_pilot: float,
        nb_steps_pilot: int,
        pilot_paths: int = 2_000,
    ):
        if not isinstance(process, (BSMilstein1D, BSMilsteinND)):
            raise TypeError("CombinedMapping nécessite BSMilstein1D ou BSMilsteinND.")

        self._process      = process
        self._main         = main_payoff
        self._cv           = cv_payoff
        self._E_cv         = E_cv
        self._anti_process = self._build_antithetic(process)
        self._beta         = self._estimate_beta(pilot_paths, T_pilot, nb_steps_pilot)

    # ------------------------------------------------------------------

    def __call__(self, T: float, nb_steps: int) -> float:
        # Chemin Z
        self._process.simulate(0.0, T, nb_steps)
        paths = self._process.get_all_paths()
        f1 = self._main(paths)
        g1 = self._cv(paths)

        # Chemin antithétique -Z
        self._anti_process.simulate(0.0, T, nb_steps)
        paths_anti = self._anti_process.get_all_paths()
        f2 = self._main(paths_anti)
        g2 = self._cv(paths_anti)

        # Moyenne antithétique
        f_avg = 0.5 * (f1 + f2)
        g_avg = 0.5 * (g1 + g2)

        # Correction par variable de contrôle
        return f_avg - self._beta * (g_avg - self._E_cv)

    # ------------------------------------------------------------------
    # Helpers privés
    # ------------------------------------------------------------------

    def _build_antithetic(self, process: RandomProcess) -> RandomProcess:
        """Construit le processus miroir avec -Z à chaque tirage gaussien."""
        anti_gen = _AntitheticNormal(process._generator)
        if isinstance(process, BSMilstein1D):
            return BSMilstein1D(anti_gen, process._spot, process._rate, process._vol)
        else:
            corr = recover_correlation(process._cholesky)
            return BSMilsteinND(
                anti_gen,
                process._spots,
                process._rates,
                process._vols,
                corr,
            )

    def _estimate_beta(
        self, pilot_paths: int, T: float, nb_steps: int
    ) -> float:
        """Estime β = Cov(f̄, ḡ) / Var(ḡ) sur une simulation pilote."""
        f_vals: List[float] = []
        g_vals: List[float] = []

        for _ in range(pilot_paths):
            # Chemin Z
            self._process.simulate(0.0, T, nb_steps)
            paths = self._process.get_all_paths()
            # Chemin -Z
            self._anti_process.simulate(0.0, T, nb_steps)
            paths_anti = self._anti_process.get_all_paths()

            f_vals.append(0.5 * (self._main(paths) + self._main(paths_anti)))
            g_vals.append(0.5 * (self._cv(paths)   + self._cv(paths_anti)))

        n  = pilot_paths
        mf = sum(f_vals) / n
        mg = sum(g_vals) / n
        cov   = sum((f_vals[j] - mf) * (g_vals[j] - mg) for j in range(n)) / (n - 1)
        var_g = sum((g_vals[j] - mg) ** 2 for j in range(n)) / (n - 1)
        return cov / var_g if var_g > 0 else 1.0

    @property
    def beta(self) -> float:
        """Coefficient optimal estimé."""
        return self._beta
