"""
LongstaffSchwartz
==================
Pricer for Bermudan options using the Longstaff-Schwartz algorithm.

Completely separate from MonteCarloPricer -- this is a fundamentally
different algorithm (backward dynamic programming, not simple averaging).

Algorithm:
  1. Simulate M paths forward -- store ALL asset values at ALL time steps
  2. Initialize: tau_j = T (everyone exercises at maturity)
  3. Backward induction from step N-1 to 1:
     a. Intrinsic value: g_j = max(basket_j - K, 0)
     b. For ITM paths: regress e^{-r*(tau_j-t_k)} * cashflow_j on basis(basket_j)
     c. Exercise if g_j >= estimated continuation value
  4. Price = mean over j of  e^{-r*tau_j} * cashflow_j

Reference: Longstaff & Schwartz (2001), "Valuing American Options by Simulation"
"""

import math
import numpy as np
from typing import List, Optional

from payoff.bermudan_payoff import BermudanBasketPayoff
from sde.random_process import RandomProcess
from .pricing_result import PricingResult


def _polynomial_basis(x: np.ndarray, degree: int) -> np.ndarray:
    """
    Build the polynomial design matrix [1, x, x^2, ..., x^degree].

    Parameters
    ----------
    x : np.ndarray, shape (n,)
    degree : int

    Returns
    -------
    np.ndarray, shape (n, degree+1)
    """
    X = np.ones((len(x), degree + 1))
    for d in range(1, degree + 1):
        X[:, d] = x ** d
    return X


class LongstaffSchwartz:
    """
    Longstaff-Schwartz algorithm for Bermudan basket option pricing.

    Parameters
    ----------
    regression_degree : int
        Degree of the polynomial used to estimate the continuation value.
        Default: 2 (basis: 1, S, S^2).
    """

    def __init__(self, regression_degree: int = 2):
        if regression_degree < 1:
            raise ValueError("regression_degree must be >= 1.")
        self._degree = regression_degree

    def price(
        self,
        bermudan_payoff: BermudanBasketPayoff,
        process: RandomProcess,
        nb_paths: int,
        nb_steps: int,
        rate: float,
    ) -> PricingResult:
        """
        Price a Bermudan Basket option.

        Parameters
        ----------
        bermudan_payoff : BermudanBasketPayoff
            Defines weights, strike, and exercise dates.
        process : RandomProcess
            N-asset Black-Scholes process with a shared generator.
        nb_paths : int
            Number of simulated paths M.
        nb_steps : int
            Number of time steps N. Exercise dates are mapped to steps.
        rate : float
            Risk-free rate r.

        Returns
        -------
        PricingResult
        """
        T        = bermudan_payoff.maturity
        ex_dates = bermudan_payoff.exercise_dates
        n_assets = bermudan_payoff.n_assets
        K        = bermudan_payoff.strike
        weights  = bermudan_payoff.weights
        dt       = T / nb_steps

        # Map exercise dates -> step indices
        exercise_steps = [round(t / dt) for t in ex_dates]

        # ---------------------------------------------------------------
        # Step 1: Simulate and store all M paths
        # all_values[asset, path, step]
        # ---------------------------------------------------------------
        all_values = np.zeros((n_assets, nb_paths, nb_steps + 1))
        for j in range(nb_paths):
            process.simulate(0.0, T, nb_steps)
            paths = process.get_all_paths()
            for i in range(n_assets):
                all_values[i, j, :] = paths[i].values

        # ---------------------------------------------------------------
        # Step 2: Initialize -- exercise at maturity
        # ---------------------------------------------------------------
        tau_step = np.full(nb_paths, exercise_steps[-1], dtype=int)

        basket_T = sum(weights[i] * all_values[i, :, exercise_steps[-1]]
                       for i in range(n_assets))
        cashflow = np.maximum(basket_T - K, 0.0)

        # ---------------------------------------------------------------
        # Step 3: Backward induction
        # ---------------------------------------------------------------
        for k in reversed(range(len(exercise_steps) - 1)):
            step_k  = exercise_steps[k]
            step_dt = (tau_step - step_k) * dt

            basket_k    = sum(weights[i] * all_values[i, :, step_k]
                              for i in range(n_assets))
            intrinsic_k = np.maximum(basket_k - K, 0.0)

            itm_mask = intrinsic_k > 0
            if not np.any(itm_mask):
                continue

            disc_cashflow = np.exp(-rate * step_dt[itm_mask]) * cashflow[itm_mask]
            x_itm = basket_k[itm_mask]
            X     = _polynomial_basis(x_itm, self._degree)

            alpha, _, _, _ = np.linalg.lstsq(X, disc_cashflow, rcond=None)
            continuation   = X @ alpha

            exercise_now   = intrinsic_k[itm_mask] >= continuation
            itm_indices    = np.where(itm_mask)[0]
            ex_idx         = itm_indices[exercise_now]

            tau_step[ex_idx] = step_k
            cashflow[ex_idx] = intrinsic_k[ex_idx]

        # ---------------------------------------------------------------
        # Step 4: Discount and average
        # ---------------------------------------------------------------
        time_to_exercise = tau_step * dt
        discounted       = np.exp(-rate * time_to_exercise) * cashflow

        # Discounting already applied per-path, so rate=0 in from_payoffs
        return PricingResult.from_payoffs(
            discounted.tolist(), rate=0.0, T=T,
            nb_paths=nb_paths, method="Longstaff-Schwartz"
        )

    # ------------------------------------------------------------------
    # Variance-reduced version
    # ------------------------------------------------------------------

    def price_with_vr(
        self,
        bermudan_payoff: BermudanBasketPayoff,
        process: RandomProcess,
        nb_paths: int,
        nb_steps: int,
        rate: float,
        antithetic: bool = False,
        cv_payoff=None,
        E_cv: float = 0.0,
    ) -> PricingResult:
        """
        Longstaff-Schwartz with optional variance reduction techniques.

        Three techniques can be combined freely:
          - antithetic : for each path Z we also simulate -Z,
            cashflows are averaged by pair before estimating the price.
          - cv_payoff  : control variate with known analytical price
            (typically GeometricBasketPayoff). The correction
            cf_j -= beta*(g_j - E[g]) is applied after the induction.
          - QMC        : plug in implicitly by passing a process
            whose generator is a SobolGenerator.

        Parameters
        ----------
        antithetic : bool
            Activate antithetic variates.
        cv_payoff : GeometricBasketPayoff or None
            Control variate payoff. Must expose analytical_price().
        E_cv : float
            Discounted expectation of the control variate:
            E_cv = cv_payoff.analytical_price()
        """
        from sde.bs_milstein_1d import BSMilstein1D
        from sde.bs_milstein_nd import BSMilsteinND
        from sde.cholesky import recover_correlation
        from .antithetic_mapping import _AntitheticNormal

        T             = bermudan_payoff.maturity
        ex_dates      = bermudan_payoff.exercise_dates
        n_assets      = bermudan_payoff.n_assets
        K             = bermudan_payoff.strike
        weights       = bermudan_payoff.weights
        dt            = T / nb_steps
        exercise_steps = [round(t / dt) for t in ex_dates]

        total = nb_paths * 2 if antithetic else nb_paths
        all_values = np.zeros((n_assets, total, nb_steps + 1))

        # -- forward simulation ------------------------------------------
        for j in range(nb_paths):
            process.simulate(0.0, T, nb_steps)
            for i in range(n_assets):
                all_values[i, j, :] = process.get_path(i).values

        if antithetic:
            anti_gen = _AntitheticNormal(process._generator)
            if isinstance(process, BSMilstein1D):
                anti_proc = BSMilstein1D(
                    anti_gen, process._spot, process._rate, process._vol)
            else:
                corr = recover_correlation(process._cholesky)
                anti_proc = BSMilsteinND(
                    anti_gen, process._spots, process._rates, process._vols, corr)
            for j in range(nb_paths):
                anti_proc.simulate(0.0, T, nb_steps)
                for i in range(n_assets):
                    all_values[i, nb_paths + j, :] = anti_proc.get_path(i).values

        # -- CV: compute g for all paths before induction ----------------
        if cv_payoff is not None:
            last_step = exercise_steps[-1]
            norm_w = [abs(w) / sum(abs(ww) for ww in weights) for w in weights]
            S_T = [all_values[i, :, last_step] for i in range(n_assets)]
            log_G = sum(norm_w[i] * np.log(np.maximum(S_T[i], 1e-12))
                        for i in range(n_assets))
            g_all = np.exp(-rate * T) * np.maximum(np.exp(log_G) - K, 0.0)

        # -- backward induction (same as price()) ------------------------
        tau_step = np.full(total, exercise_steps[-1], dtype=int)
        basket_T = sum(weights[i] * all_values[i, :, exercise_steps[-1]]
                       for i in range(n_assets))
        cashflow = np.maximum(basket_T - K, 0.0)

        for k in reversed(range(len(exercise_steps) - 1)):
            step_k  = exercise_steps[k]
            step_dt = (tau_step - step_k) * dt

            basket_k    = sum(weights[i] * all_values[i, :, step_k]
                              for i in range(n_assets))
            intrinsic_k = np.maximum(basket_k - K, 0.0)
            itm_mask    = intrinsic_k > 0
            if not np.any(itm_mask):
                continue

            disc_cashflow = np.exp(-rate * step_dt[itm_mask]) * cashflow[itm_mask]
            X = _polynomial_basis(basket_k[itm_mask], self._degree)
            alpha, _, _, _ = np.linalg.lstsq(X, disc_cashflow, rcond=None)
            continuation   = X @ alpha

            exercise_now = intrinsic_k[itm_mask] >= continuation
            itm_indices  = np.where(itm_mask)[0]
            ex_idx       = itm_indices[exercise_now]
            tau_step[ex_idx] = step_k
            cashflow[ex_idx] = intrinsic_k[ex_idx]

        time_to_exercise = tau_step * dt
        discounted = np.exp(-rate * time_to_exercise) * cashflow

        # -- antithetic averaging ----------------------------------------
        if antithetic:
            discounted = 0.5 * (discounted[:nb_paths] + discounted[nb_paths:])
            if cv_payoff is not None:
                g_all = 0.5 * (g_all[:nb_paths] + g_all[nb_paths:])

        # -- control variate correction ----------------------------------
        if cv_payoff is not None:
            cov_fg = np.cov(discounted, g_all)[0, 1]
            var_g  = np.var(g_all, ddof=1)
            beta   = cov_fg / var_g if var_g > 0 else 0.0
            discounted = discounted - beta * (g_all - E_cv)

        return PricingResult.from_payoffs(
            discounted.tolist(), rate=0.0, T=T,
            nb_paths=nb_paths, method="LS-VR"
        )
